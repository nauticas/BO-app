<?php $__env->startSection('content'); ?>
        <div class="col-md-12">
            <div class="card">
                <div class="header">
                    <h4 class="title"><?php echo e($title); ?></h4>
                    <p class="category"></p>
                </div>
                <div class="content">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>NIM</label>
                                <input type="text" class="form-control border-input" value="<?php echo e($mahasiswa->nim); ?>" name="nim" disabled>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Tahun Ajaran</label>
                                <input type="text" class="form-control border-input" value="<?php echo e($thn_ajaran->keterangan); ?>" name="thn_ajaran" disabled>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Nama</label>
                                <input type="text" class="form-control border-input" value="<?php echo e($mahasiswa->nama_mahasiswa); ?>" name="nama_mahasiswa" disabled>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="form-group">
                                <label>IP Semester Tahun Lalu</label>
                                <input type="text" class="form-control border-input" value="<?php echo e($ipk->IPK); ?>" name="thn_ajaran" disabled>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="form-group">
                                <label>Beban Study Maks</label>
                                <input type="text" class="form-control border-input" value="<?php echo e($beban_studi); ?>" name="thn_ajaran" disabled>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Jurusan</label>
                                <input type="text" class="form-control border-input" value="<?php echo e($mahasiswa->jurusan); ?>" name="jurusan" disabled>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Program</label>
                                <input type="text" class="form-control border-input" value="<?php echo e($mahasiswa->kelas_program); ?>" name="kelas_program" disabled>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Dosen Wali</label>
                                <input type="text" class="form-control border-input" value="<?php echo e($mahasiswa->dosen->nama_dosen); ?>" name="nama_dosen" disabled>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Semester Yang Akan Ditempuh</label>
                                <input type="text" class="form-control border-input" value="<?php echo e($semester); ?>" name="kelas_program" disabled>
                            </div>
                        </div>
                    </div>
                    <table class="table table-bordered table-condensed">
                        <thead>
                            <tr>
                                <th colspan="11" class="text-center">MATA KULIAH YANG AKAN DITEMPUH PADA SEMESTER INI :</th>
                            </tr>
                            <tr>
                                <th>Kode MK</th>
                                <th>Mata Kuliah</th>
                                <th>Semester</th>
                                <th>SKS</th>
                                <th>Dosen</th>
                                <th>Kelas</th>
                                <th>Jadwal</th>
                                <th>Quota</th>
                                <th>Peserta</th>
                                <th>Calon Peserta</th>
                            </tr>
                            <?php $total_sks =0 ?>
                            <?php $__currentLoopData = $krs->krsdetil; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $telo): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                            <tr>
                                <td><?php echo e($telo->jadwal->matakuliah->kd_mk); ?></td>
                                <td><?php echo e($telo->jadwal->matakuliah->nama_mk); ?></td>
                                <td><?php echo e($telo->jadwal->matakuliah->semester); ?></td>
                                <?php 
                                    $total_sks = $total_sks + $telo->jadwal->matakuliah->sks; 
                                ?>
                                <td><?php echo e($telo->jadwal->matakuliah->sks); ?></td>
                                <td><?php echo e($telo->jadwal->dosen->nama_dosen); ?></td>
                                <td><?php echo e($telo->jadwal->program); ?></td>
                                <td><?php echo e($telo->jadwal->jadwal); ?></td>
                                <td><?php echo e($telo->jadwal->kapasitas); ?></td>
                                <td><?php echo e($peserta[$telo->jadwal->id]); ?></td>
                                <td><?php echo e($calon_peserta[$telo->jadwal->id]); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                            <tr>
                                <td colspan="3">Total SKS Yang Akan Ditempuh </td>
                                <td colspan="9"><?php echo e($total_sks); ?></td>
                            </tr>
                        </thead>
                        <tbody>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>