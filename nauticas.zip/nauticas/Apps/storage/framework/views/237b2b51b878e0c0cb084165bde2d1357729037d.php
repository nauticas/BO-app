<?php $__env->startSection('content'); ?>
<div class="col-md-12">
	<div class="box">
		<div class="box-header with-border">
			<h4 class=""><?php echo e($title); ?></h4>
			<p class="category"></p>
		</div>
		<div class="content">
			<form action="<?php echo e(route('ruang.update',$ruang->id)); ?>" method="POST">
				<?php echo e(csrf_field()); ?>

				<input type="hidden" name="_method" value="PUT">
				<div class="row">
					<div class="col-md-10">
						<div class="form-group <?php if($errors->has('nama_ruang')): ?> has-error <?php endif; ?>">
							<label>Nama ruang</label>
							<input type="text" class="form-control border-input" value="<?php echo e($ruang->nama_ruang); ?>" name="nama_ruang">
							<span id="helpBlock2" class="help-block"><?php echo e($errors->first('nama_ruang')); ?></span>
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-md-12">
						<a href="<?php echo e(route('ruang.index')); ?>" class="btn btn-warning">Cancel</a>
						<input type="submit" class="btn btn-success">
					</div>
				</div>
			</form>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>