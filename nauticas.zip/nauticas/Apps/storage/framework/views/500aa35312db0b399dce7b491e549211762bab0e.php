<?php $__env->startSection('content'); ?>
        <div class="col-md-12">
            <div class="card">
                <div class="header">
                    <h4 class="title"><?php echo e($title); ?></h4>
                    <p class="category"></p>
                </div>
                <div class="content table-responsive table-full-width">
                    <table class="table table-striped">
                        <thead>
                            <th>Kode MataKuliah</th>
                            <th>Nama Matakuliah</th>
                            <th>Kode Dosen</th>
                            <th>NIDN</th>
                            <th>Nama Dosen</th>
                            <th>Jadwal</th>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $matakuliah->jadwal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dos): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                            <form action="<?php echo e(route('dosen.destroy',$dos->id)); ?>" method="post"  class="form-inline">
                            <tr>
                                <td><?php echo e($matakuliah->kd_mk); ?></td>
                                <td><?php echo e($matakuliah->nama_mk); ?></td>
                                <td><?php echo e($dos->dosen->kode_dosen); ?></td>
                                <td><?php echo e($dos->dosen->nidn); ?></td>
                                <td><?php echo e($dos->dosen->nama_dosen); ?></td>
                                <td><?php echo e($dos->jadwal.' / '.$dos->ruang->nama_ruang); ?></td>
                            </tr>
                            </form>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>