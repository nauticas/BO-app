<?php if(Auth::check()): ?>
<div class="sidebar" data-background-color="white" data-active-color="danger">
    <div class="sidebar-wrapper">

            <?php if(Auth::user()->role == 'admin'): ?>
            <div class="logo">
                <a href="http://www.creative-tim.com" class="simple-text">
                    Selamat Datang <?php echo e(Auth::user()->username); ?>

                </a>
            </div>

            <ul class="nav">
            <li class="<?php echo e(Request::segment(2) == '' ? 'active' : ''); ?>">
                <a href="<?php echo e(route('admin')); ?>">
                    <i class="ti-panel"></i>
                    <p>Dashboard</p>
                </a>
            </li>
            <li class="<?php echo e(Request::segment(2) == 'dosen' ? 'active' : ''); ?>">
                <a href="<?php echo e(route('dosen.index')); ?>">
                    <i class="ti-view-list-alt"></i>
                    <p>Dosen</p>
                </a>
            </li>
            <li class="<?php echo e(Request::segment(2) == 'mahasiswa' ? 'active' : ''); ?>">
                <a href="<?php echo e(route('mahasiswa.index')); ?>">
                    <i class="ti-text"></i>
                    <p>Mahasiswa</p>
                </a>
            </li>
            <li class="<?php echo e(Request::segment(2) == 'matakuliah' ? 'active' : ''); ?>">
                <a href="<?php echo e(route('matakuliah.index')); ?>">
                    <i class="ti-pencil-alt2"></i>
                    <p>Mata Kuliah</p>
                </a>
            </li>
            <li class="<?php echo e(Request::segment(2) == 'ruang' ? 'active' : ''); ?>">
                <a href="<?php echo e(route('ruang.index')); ?>">
                    <i class="ti-map"></i>
                    <p>Ruang</p>
                </a>
            </li>
            <li class="<?php echo e(Request::segment(2) == 'jadwal' ? 'active' : ''); ?>">
                <a href="<?php echo e(route('jadwal.index')); ?>">
                    <i class="ti-bell"></i>
                    <p>Jadwal Kuliah</p>
                </a>
            </li>
            <li class="<?php echo e(Request::segment(2) == 'thnajaran' ? 'active' : ''); ?>">
                <a href="<?php echo e(route('thnajaran.index')); ?>">
                    <i class="ti-bell"></i>
                    <p>Tahun Ajaran</p>
                </a>
            </li>
            <?php elseif(Auth::user()->role == 'mahasiswa'): ?>
            <div class="logo">
                <a href="http://www.creative-tim.com" class="simple-text">
                    Selamat Datang <?php echo e(Auth::user()->mahasiswa->nama_mahasiswa); ?>

                </a>
            </div>

            <ul class="nav">
            <li class="<?php echo e(Request::segment(2) == '' ? 'active' : ''); ?>">
                <a href="<?php echo e(route('mahasiswa')); ?>">
                    <i class="ti-panel"></i>
                    <p>Dashboard</p>
                </a>
            </li>
            <li class="<?php echo e(Request::segment(2) == 'krs' ? 'active' : ''); ?>">
                <a href="<?php echo e(route('krs.index')); ?>">
                    <i class="ti-panel"></i>
                    <p>Kartu Rencana Studi</p>
                </a>
            </li>
            <li class="<?php echo e(Request::segment(2) == 'khs' ? 'active' : ''); ?>">
                <a href="<?php echo e(route('khs.index')); ?>">
                    <i class="ti-panel"></i>
                    <p>Kartu Hasil Studi</p>
                </a>
            </li>
            <?php else: ?>
            <div class="logo">
                <a href="http://www.creative-tim.com" class="simple-text">
                    Selamat Datang <?php echo e(Auth::user()->dosen->nama_dosen); ?>

                </a>
            </div>

            <ul class="nav">
            <li class="<?php echo e(Request::segment(2) == '' ? 'active' : ''); ?>">
                <a href="<?php echo e(route('dosen')); ?>">
                    <i class="ti-panel"></i>
                    <p>Dashboard</p>
                </a>
            </li>
            <li class="<?php echo e(Request::segment(2) == 'persetujuan' ? 'active' : ''); ?>">
                <a href="<?php echo e(route('persetujuan.index')); ?>">
                    <i class="ti-panel"></i>
                    <p>Persetujuan KRS</p>
                </a>
            </li>
            <li class="<?php echo e(Request::segment(2) == 'nilai' ? 'active' : ''); ?>">
                <a href="<?php echo e(route('nilai.index')); ?>">
                    <i class="ti-panel"></i>
                    <p>Input Nilai</p>
                </a>
            </li>
            <?php endif; ?>
        </ul>
    </div>
</div>
<?php endif; ?>