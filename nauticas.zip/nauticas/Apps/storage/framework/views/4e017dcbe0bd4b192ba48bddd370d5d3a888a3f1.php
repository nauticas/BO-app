<?php $__env->startSection('content'); ?>
<div class="col-md-12">
    <div class="box">
        <div class="box-header with-border">
            <h4 class=""><?php echo e($title); ?></h4>
            <p class="category"></p>
        </div>
        <div class="content table-responsive">
            <a href="<?php echo e(route('jadwal.create')); ?>" class="btn btn-success btn-xs"><span class="fa fa-plus"></span> Tambah Jadwal</a>
            <table class="table table-condensed">
                <thead>
                    <th>Kode Mata Kuliah</th>
                    <th>Mata Kuliah</th>
                    <th>Semester</th>
                    <th>SKS</th>
                    <th colspan="2">Dosen</th>
                    <th>Kelas</th>
                    <th>Jadwal</th>
                    <th>Quota</th>
                    <th>Peserta</th>
                    <th>Calon Peserta</th>
                    <th>Aksi</th>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $matakuliah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mk): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    <tr>
                        <td rowspan="<?php echo e($mk->jadwal->count()+1); ?>"><?php echo e($mk->kd_mk); ?></td>
                        <td rowspan="<?php echo e($mk->jadwal->count()+1); ?>"><?php echo e($mk->nama_mk); ?></td>
                        <td rowspan="<?php echo e($mk->jadwal->count()+1); ?>"><?php echo e($mk->semester); ?></td>
                        <td rowspan="<?php echo e($mk->jadwal->count()+1); ?>"><?php echo e($mk->sks); ?></td>
                    </tr>
                    
                    <?php $__currentLoopData = $mk->jadwal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jadwal): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    
                    <form action="" method="post"  class="form-inline">
                        <tr>
                            <td><?php echo e($jadwal->dosen->kode_dosen); ?></td>
                            <td><?php echo e($jadwal->dosen->nama_dosen); ?></td>
                            <td><?php echo e($jadwal->kelas); ?></td>
                            <td><?php echo e($jadwal->jadwal.' / '.$jadwal->ruang->nama_ruang); ?></td>
                            <td><?php echo e($jadwal->kapasitas); ?></td>
                            <td><?php echo e($peserta[$jadwal->id]); ?></td>
                            <td><?php echo e($calon_peserta[$jadwal->id]); ?></td>
                            <td>
                                <a href="<?php echo e(route('jadwal.edit',$jadwal->id)); ?>" class="btn btn-info btn-xs"><i class="fa fa-pencil"></i></a>
                                <?php echo e(csrf_field()); ?>

                                <input type="hidden" name="_method" value="delete" >
                                <button type="submit" class="btn btn-danger btn-xs"><i class="fa fa-close"></i></a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                    </form>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                </tbody>
            </table>
            <?php echo e($matakuliah->links()); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>